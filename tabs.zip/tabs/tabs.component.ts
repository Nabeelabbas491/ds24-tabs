import { Component, EventEmitter, Input, Output } from '@angular/core';
import { Tab } from 'src/app/types/tab.type';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.scss']
})
export class TabsComponent {

  @Output() onSelection = new EventEmitter<Tab>()
  @Input() items: Tab[] = []
  selectedTabId: string = ''

  selectTab(item: Tab) {
    this.selectedTabId = item.id
    this.onSelection.emit(item)
  }

}

