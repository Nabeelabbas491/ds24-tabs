export interface Tab {
    title: string
    id: TabId
}

export type TabId = "bookings" | "appointments" | "settings"