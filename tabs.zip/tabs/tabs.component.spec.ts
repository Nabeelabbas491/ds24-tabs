import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabsComponent } from './tabs.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('TabsComponent', () => {
  let component: TabsComponent;
  let fixture: ComponentFixture<TabsComponent>;
  let button: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TabsComponent]
    });
    fixture = TestBed.createComponent(TabsComponent);
    component = fixture.componentInstance;
    component.items = [{ title: 'Settings', id: "settings" }]
    fixture.detectChanges();
    button = fixture.debugElement.query(By.css('button'))
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it("should call the selectTab function on click ", () => {
    jest.spyOn(component, 'selectTab');
    button.triggerEventHandler("click", {})
    fixture.detectChanges()
    expect(component.selectTab).toHaveBeenCalled()
  })

  it("should set the selected tab with clicked tab id", () => {
    jest.spyOn(component, 'selectTab');
    button.triggerEventHandler("click", {})
    fixture.detectChanges()
    expect(component.selectedTabId).toEqual('settings')
  })

  it("should emit the event on click", () => {
    let eventEmitted = false
    component.onSelection.subscribe(() => { eventEmitted = true })
    button.triggerEventHandler("click", {})
    expect(eventEmitted).toBe(true);
  })

  it("emitted event should emit the selected tab object", () => {
    let eventValue
    component.onSelection.subscribe(($event) => { eventValue = $event })
    button.triggerEventHandler("click", {})
    expect(eventValue).toBe(component.items[0]);
  })

})